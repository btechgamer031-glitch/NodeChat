# Node Chat VPS Panel

Starter self-hosted Node.js panel with email/password register/login, optional Discord OAuth, My VPS, Docker VPS, Invite & Earn, Boosts, Support VPS, Chatting VPS, Settings, and an admin overview.

## Install on Ubuntu/Debian
```bash
sudo apt update
sudo apt install -y nodejs npm unzip
unzip node-chat-panel.zip
cd node-chat-panel
cp .env.example .env
nano .env
npm install
npm start
```
Then open `http://YOUR_SERVER_IP:3000`. Use Nginx and HTTPS before exposing it publicly.

## Admin account
Set `ADMIN_EMAILS=your-email@example.com` in `.env`, then register with that exact email.

## Discord login setup
Create an app at https://discord.com/developers/applications. Add the OAuth2 redirect URL `https://YOUR_DOMAIN/auth/discord/callback` and set `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`, and `DISCORD_CALLBACK_URL` in `.env`. Set a long random `SESSION_SECRET`. The Discord invite used by this panel is https://discord.gg/ddEuhTM6bB.

## Important limitations / safety
- Docker container creation is disabled by default (`ENABLE_DOCKER_CREATE=false`). Only enable it on a dedicated, secured Docker host after reviewing risks.
- Docker containers are not full virtual machines. Production use needs stronger isolation, network/firewall policy, quotas, logging, abuse controls, and cleanup.
- Invite/boost counts are placeholders and higher-RAM plans stay locked until you implement server-side Discord bot verification. Do not trust counts sent by a browser.
- Use HTTPS, a reverse proxy, backups, and a long random session secret before public deployment.
